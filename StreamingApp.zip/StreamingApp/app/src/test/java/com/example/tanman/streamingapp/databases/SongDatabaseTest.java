package com.example.tanman.streamingapp.databases;

import org.junit.Before;
import org.junit.Test;
public class SongDatabaseTest {

    @Before
    public void createDB() {
    }

    @Test
    public void songDao() {
    }

    @Test
    public void getInstance() {
    }
}