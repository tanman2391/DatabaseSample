package com.example.tanman.streamingapp.viewmodels;

import android.arch.lifecycle.LiveData;

import com.example.tanman.streamingapp.entities.SongEntity;

import org.junit.Test;

import java.util.List;

public class SongViewModelTest {
    SongViewModel viewModel;
    LiveData<List<SongEntity>> allSongs;

    @Test
    public void delete() {

    }

    @Test
    public void deleteAll() {
    }

    @Test
    public void getAllSongs() {

    }
}